def splitList2Parts(input_list, num_parts):
    if num_parts <= 0:
        return (input_list, [])
    avg_part_size = len(input_list) // num_parts
    remainder = len(input_list) % num_parts

    parts = []
    start_idx = 0

    for i in range(num_parts):
        part_size = avg_part_size + 1 if i < remainder else avg_part_size
        end_idx = start_idx + part_size
        parts.append(input_list[start_idx:end_idx])
        start_idx = end_idx

    return parts



def fillChar(number, maxLength : int, pat : str, back : bool):
    str_num = str(number)
    if(back):
        return str_num + pat * (maxLength - len(str_num))
    else:
        return pat * (maxLength - len(str_num)) + str_num



def NoneCat(str):
    if str is not None:
        return str
    else:
        return "None"
    
def getGenderNum(year : str, gender : str) -> str:
    century  = int(year[0] + year[1]) + 1
    if(century == 21 and gender == 'm'):
        return '5'
    elif(century == 21 and gender == 'f'):
        return '6'
    elif(century == 20 and gender == 'm'):
        return '3'
    elif(century == 20 and gender == 'f'):
        return '4'
    elif(century == 19 and gender == 'm'):
        return '1'
    elif(century == 19 and gender == 'f'):
        return '2'
    


def getIinList(sDay : int, sMonth : int, sYear : int, eDay : int, eMonth : int, eYear : int, gender : str, sIndex : int, eIndex : int) -> list:
    iinList = []
    for year in range(sYear, eYear + 1):
        for month in range(sMonth, eMonth + 1):
            for day in range(sDay,eDay + 1):
                print(type(getGenderNum(str(year), gender)))
                iin = str(year).replace(str(year)[0] + str(year)[1],"") + fillChar(month, 2, '0', False) + fillChar(day, 2, '0', False) + getGenderNum(str(year), gender)
                for i in range(sIndex,eIndex):
                    iinCopy = iin
                    iinCopy = iinCopy + fillChar(i, 4, '0', False)
                    v = []
                    for j in range(0, len(iinCopy)):
                        v.append(int(iinCopy[j]))
                    is_actual = False
                    n12 = (1*v[0] + 2*v[1] + 3*v[2] + 4*v[3] + 5*v[4] + 6*v[5] + 7*v[6] + 8*v[7] + 9*v[8] + 10*v[9] + 11*v[10]) % 11
                        
                    if n12 == 10:
                        n12 = (3*v[0] + 4*v[1] + 5*v[2] + 6*v[3] + 7*v[4] + 8*v[5] + 9*v[6] + 10*v[7] + 11*v[8] + 1*v[9] + 2*v[10]) % 11
                        if n12 != 10:
                            is_actual = True
                    else:
                        is_actual = True
                    if(is_actual):
                        iinList.append(iinCopy + str(n12))
    return iinList



def getGenderNum(year : str, gender : str) -> str:
    century  = int(year[0] + year[1]) + 1
    if(century == 21 and gender == 'm'):
        return '5'
    elif(century == 21 and gender == 'f'):
        return '6'
    elif(century == 20 and gender == 'm'):
        return '3'
    elif(century == 20 and gender == 'f'):
        return '4'
    elif(century == 19 and gender == 'm'):
        return '1'
    elif(century == 19 and gender == 'f'):
        return '2'
    
def write_to_file_safely(file_path, content):
    try:
        with open(file_path, 'a') as file:
            file.write(content)
        print(f"Successfully wrote to {file_path}")
    except Exception as e:
        print(f"Error writing to {file_path}: {e}")

