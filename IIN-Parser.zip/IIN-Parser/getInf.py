from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import json
 
def NoneCat(str):
    if str is not None:
        return str
    else:
        return "None"
def getInf(iin : str):
    browser.get("https://www.enbek.kz/ru/cabinet/otib/attestation/iin/" + iin)
    soup = BeautifulSoup(browser.page_source, 'html.parser')
    pre_tag = soup.find('pre', style='word-wrap: break-word; white-space: pre-wrap;')
    json_data = pre_tag.get_text()
    data = json.loads(json_data)
    return json.dumps(data, indent=3, ensure_ascii=False).replace("{","").replace("}","")
    
options = Options()
options.add_argument("user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36")
options.add_argument('--headless')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.add_argument("--disable-blink-features=AutomationControlled")
browser = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
browser.maximize_window()
browser.get("https://passport.enbek.kz/ru/user/login")
email = browser.find_element(By.NAME, "email")
email.send_keys("eshtai94@mail.ru")

password = browser.find_element(By.NAME, "password")
password.send_keys("Galia1994!")

continue_button = browser.find_element(By.XPATH, value="//button[@type='submit']")
continue_button.click()

iin = input("IIN : ")
print(getInf(iin))